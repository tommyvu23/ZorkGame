package Main;

public class room {
    public String nameOfRoom;

    public room(String RoomName){
        nameOfRoom = RoomName;
    }
}
