package Main;

import java.util.ArrayList;
import java.util.Scanner;


public class main {
    //Possible commands
    public static final String[] PossibleVerbs = { "open", "close", "take", "walk", "use", "inventory", "examine" };

    // name, description, portable, openable, usable, unlocked, opened
    static room currentRoom = new room("bedroom");

    static items west = new items("west", "", false, false, false, false, false);
    static items north = new items("north", "", false, false, false, false, false);
    static items south = new items("south", "", false, false, false, false, false);
    static items east = new items("east", "", false, false, false, false, false);

    // Master Bedroom
    static items bed = new items("bed", "A queen sized bed. There's a pillow on the bed.", false, false, false,
            false, false);
    static items pillow = new items("pillow", "A dirty looking pillow", false, false, false, false, false);
    static items nightstand = new items("nightstand", "A common wooden nightstand", false, true, false, true, false);
    static items small_key = new items("small_key", "A small looking key. This seems to open a toolbox.", true, false, true, false, false);
    static items bedroom_door = new items("bedroom_door", "A door that lets you exit the bedroom.", false, true, true, true, true);


    // bathroom
    static items bathroom_door = new items("bathroom_door", "A door that lets you enter the bathroom.", false, true, true, true, true);
    static items bathroom_cabinet = new items("cabinet", "A cabinet. It seems like this is unlocked.", false, true, false, false, false);
    static items bandages = new items("bandages", "An unopened box of bandage.", true, false, true, false, false);


    // Garden
    static items car_key = new items("car_key", "This appears to be a car key. It has a fob key ring.", true, false, true, false, false);
    static items garden_door = new items("garden_door", "A door that leads to the garden.", false, true, true, true, true);
    static items bushes = new items("bushes", "Relatively healthy looking bushes. They have thorns, so you cannot pass by them.", false, false, false, false,
            false);
    static items statue = new items("statue", "A beautifully sculpted statue. It appears to have some object lodged inside of it.", false, false, true, false, false);

    // Living Room
    static items television = new items("television", "An old looking television. It seems to be playing Tom N Jerry.", false, false, false, false,
            false);
    static items sofa = new items("sofa", "A brown sofa which seems expensive.", false, false, false, false, false);
    static items livingroom_door = new items("living room_door", "A door that leads to the living room.", false, true, true, true, true);


    // Garage
    static items tool_box = new items("tool_box", "A tool box with a small lock. Maybe a small key can open it.", false, true, true, false, false);
    static items hammer = new items("hammer", "A sturdy looking hammer. Perhaps it can smash stone.", true, false, true,
            false, false);
    static items car = new items("car", "A car. It seems that it still works.", false, true, true, false, false);
    static items garage_door = new items("garage_door", "A door that leads to the garage.", false, true, true, true, true);

    // Dining room
    static items food = new items("food", "Some kentucky fried chicken, which seems delicious.", true, false, true, false,
            false);


    // Kitchen
    static items knife_rack = new items("knife_rack", "A common looking knife rack. Maybe you should take one.", true, false, true, false, false);
    static items knife = new items("knife", "A relatively sharp knife.", true, false, true, false, false);
    static items kitchen_door = new items("kitchen_door", "A door that leads to the kitchen room.", false, true, true, true, true);



    //Large hallway
    static items killer = new items("killer", "A big guy with a hockey mask and machete.", false, false, false, false, false);
    static items golden_key = new items("golden_key", "A gold colored key. Maybe it opens the main door", true, false, true, false, false);
    static items hallway_door = new items("hallway_door", "A door that leads you to the hallway.", false, true, true, true, true);


    //Foyer
    static items front_door = new items("front_door", "A door that leads you to freedom.", false, true, true, false, false);
    static items leg = new items("front_door", "A door that leads you to freedom.", false, false, true, false, false);


    static ArrayList<items> inventory = new ArrayList<>();
    static ArrayList<items> Room = new ArrayList<>();
    static ArrayList<items> ObjectsInBedroom = new ArrayList<>();
    static ArrayList<items> ObjectsInBathroom = new ArrayList<>();
    static ArrayList<items> ObjectsInGarden = new ArrayList<>();
    static ArrayList<items> ObjectsInLivingroom = new ArrayList<>();
    static ArrayList<items> ObjectsInGarage = new ArrayList<>();
    static ArrayList<items> ObjectsInDiningroom = new ArrayList<>();
    static ArrayList<items> ObjectsInKitchen = new ArrayList<>();
    static ArrayList<items> ObjectsInLargeHallway = new ArrayList<>();
    static ArrayList<items> ObjectsInFoyer = new ArrayList<>();
    static ArrayList<items> ObjectsInLitHallway = new ArrayList<>();
    static ArrayList<items> ObjectsInDarkHallway = new ArrayList<>();

    static boolean game = true;

    public static void main(String[] args) {

        ObjectsInBedroom.add(bed);
        ObjectsInBedroom.add(nightstand);
        ObjectsInBedroom.add(pillow);
        ObjectsInBedroom.add(bedroom_door);
        ObjectsInBedroom.add(small_key);
        ObjectsInBedroom.add(west);
        ObjectsInBedroom.add(east);
        ObjectsInBedroom.add(north);
        ObjectsInBedroom.add(south);
        ObjectsInBedroom.add(leg);


        ObjectsInBathroom.add(west);
        ObjectsInBathroom.add(east);
        ObjectsInBathroom.add(south);
        ObjectsInBathroom.add(north);
        ObjectsInBathroom.add(bathroom_door);
        ObjectsInBathroom.add(bathroom_cabinet);
        ObjectsInBathroom.add(bandages);
        ObjectsInBathroom.add(leg);

        ObjectsInGarden.add(west);
        ObjectsInGarden.add(east);
        ObjectsInGarden.add(south);
        ObjectsInGarden.add(north);
        ObjectsInGarden.add(car_key);
        ObjectsInGarden.add(garage_door);
        ObjectsInGarden.add(bushes);
        ObjectsInGarden.add(leg);
        ObjectsInGarden.add(statue);

        ObjectsInLivingroom.add(west);
        ObjectsInLivingroom.add(east);
        ObjectsInLivingroom.add(south);
        ObjectsInLivingroom.add(north);
        ObjectsInLivingroom.add(television);
        ObjectsInLivingroom.add(sofa);
        ObjectsInLivingroom.add(leg);

        ObjectsInGarage.add(west);
        ObjectsInGarage.add(east);
        ObjectsInGarage.add(south);
        ObjectsInGarage.add(north);
        ObjectsInGarage.add(tool_box);
        ObjectsInGarage.add(hammer);
        ObjectsInGarage.add(car);
        ObjectsInGarage.add(garage_door);
        ObjectsInGarage.add(leg);


        ObjectsInDiningroom.add(west);
        ObjectsInDiningroom.add(east);
        ObjectsInDiningroom.add(north);
        ObjectsInDiningroom.add(south);
        ObjectsInDiningroom.add(food);
        ObjectsInDiningroom.add(leg);


        ObjectsInKitchen.add(west);
        ObjectsInKitchen.add(east);
        ObjectsInKitchen.add(north);
        ObjectsInKitchen.add(south);
        ObjectsInKitchen.add(kitchen_door);
        ObjectsInKitchen.add(knife);
        ObjectsInKitchen.add(knife_rack);
        ObjectsInKitchen.add(leg);


        ObjectsInLargeHallway.add(west);
        ObjectsInLargeHallway.add(east);
        ObjectsInLargeHallway.add(north);
        ObjectsInLargeHallway.add(south);
        ObjectsInLargeHallway.add(killer);
        ObjectsInLargeHallway.add(golden_key);
        ObjectsInLargeHallway.add(hallway_door);
        ObjectsInLargeHallway.add(leg);

        ObjectsInFoyer.add(west);
        ObjectsInFoyer.add(east);
        ObjectsInFoyer.add(north);
        ObjectsInFoyer.add(south);
        ObjectsInFoyer.add(front_door);
        ObjectsInFoyer.add(leg);

        ObjectsInLitHallway.add(west);
        ObjectsInLitHallway.add(east);
        ObjectsInLitHallway.add(north);
        ObjectsInLitHallway.add(south);
        ObjectsInLitHallway.add(bedroom_door);
        ObjectsInLitHallway.add(bathroom_door);
        ObjectsInLitHallway.add(hallway_door);
        ObjectsInLitHallway.add(leg);

        ObjectsInDarkHallway.add(west);
        ObjectsInDarkHallway.add(east);
        ObjectsInDarkHallway.add(north);
        ObjectsInDarkHallway.add(south);
        ObjectsInDarkHallway.add(garden_door);
        ObjectsInDarkHallway.add(livingroom_door);
        ObjectsInDarkHallway.add(leg);


        Scanner input = new Scanner(System.in);
        boolean running = true;
        boolean valid;
        String[] tokens;
        String answer = "";
        String command, object, object2;
        Room = ObjectsInBedroom;
        currentRoom.nameOfRoom = "bedroom";
        System.out.println(
                "You wake up in a bedroom. It smells of moldy wood. \nYou are unsure of how you got here. You just know that you have to escape!\nYou are in a relatively big bedroom. There is a door south of the room.\nThere is a nightstand east of the room.\nAlso, there is a pillow on the bed. ");
        while (game == true) {
            do {
                RoomSelect();
                answer = input.nextLine();
                tokens = answer.split("\\s+");
                valid = checkCommand(tokens[0]);
                if (!valid) {
                    System.out.println("I don't know how to " + tokens[0]);
                }
            } while (!valid);
            if (tokens.length == 1) {
                command = tokens[0].toLowerCase();
                if (command.equals("inventory")) {
                    Inventory();
                } else {
                    System.out.println("I cannot understand you.");
                }
            } else if (tokens.length == 2) {
                command = tokens[0].toLowerCase();
                object = tokens[1].toLowerCase();
                if (checkObject(object)) {
                    if (command.equals("open")) {
                        Open(object);
                    } else if (command.equals("examine")) {
                        Examine(object);
                    } else if (command.equals("walk")) {
                        Walk(object);
                    } else if (command.equals("use")) {
                        System.out.println("You cannot do such a thing");
                    }

                } else if (checkInventory(object) && command.equals("examine")) {
                    Examine(object);
                } else if (checkInventory(object) && command.equals("use")) {
                    System.out.println("You should say your target");
                } else if (object.equals("room") && command.equals("examine")) {
                    if (currentRoom.nameOfRoom.equals("bedroom")) {
                        System.out.println(
                                "You see a pillow and a nightstand in this room. There is also a door to the south of the room.");
                    } else if (currentRoom.nameOfRoom.equals("bathroom")) {
                        System.out.println(
                                "It is a bathroom. \nThere is a cabinet with a red cross on it. There is a door south.");

                    } else if (currentRoom.nameOfRoom.equals("lit hallway")) {
                        System.out.println(
                                "It is a narrow corridor and there is not much to it. There is a door to the bathroom on the east.");


                    } else if (currentRoom.nameOfRoom.equals("dark hallway")) {
                        System.out.println(
                                "It is a narrow corridor that is pretty dark. There is a garden door to the east and a garage door to the west.");

                    } else if (currentRoom.nameOfRoom.equals("garden")) {
                        System.out.println(
                                "There's some fresh air in this garden. You can see a statue with something inside of it. Maybe we have to break it.");

                    } else if (currentRoom.nameOfRoom.equals("living room")) {
                        System.out.println(
                                "It's a pretty standard living room. There is a television playing there. There is a door to the north which leads to the garage. There is a door to the west that leads to a hallway.");

                    } else if (currentRoom.nameOfRoom.equals("garage")) {
                        System.out.println(
                                "A typical garage. Relatively spacious. There is a car there that seems to need a key to drive. Maybe you can bust out of the place with the car.");

                    } else if (currentRoom.nameOfRoom.equals("dining room")) {
                        System.out.println(
                                "It's a dining room with food on the table still.\nThere is a door to the kitchen to the south. ");

                    } else if (currentRoom.nameOfRoom.equals("kitchen")) {
                        System.out.println(
                                "A beautiful looking kitchen. \nThere's a knife rack on the counter. There's a door leading to the foyer to the west.");

                    } else if (currentRoom.nameOfRoom.equals("large hallway")) {
                        System.out.println(
                                "It's a large hallway. There seems to be some large object standing in the middle of it. \nYou should be careful.");

                    } else if (currentRoom.nameOfRoom.equals("foyer")) {
                        System.out.println(
                                "It's a pretty big foyer. The door leading to the outside is there. It appears to be locked. \n There's a door to the west that leads to the garage.");

                    }
                } else {
                    System.out.println("There is no such a thing");
                }
            } else if (tokens.length == 3) {
                command = tokens[0].toLowerCase();
                object = tokens[1].toLowerCase();
                object2 = tokens[2].toLowerCase();
                if ((checkObject(object2) || checkInventory(object2)) && checkInventory(object)) {
                    if (command.equals("use")) {
                        Use(object, object2);
                    } else {
                        System.out.println("I cannot understand you");
                    }
                } else if (checkInventory(object) && !(checkObject(object2) || checkInventory(object2))) {
                    System.out.print("There is no " + object2);
                } else if (!checkInventory(object) && (checkObject(object2) || checkInventory(object2))) {
                    System.out.print("You have no " + object + " in your inventory");
                } else {
                    System.out.println("I cannot understand you");
                }
            }
        }
    }


    public static boolean checkCommand(String verb) {
        verb = verb.toLowerCase();
        for (int i = 0; i < PossibleVerbs.length; i++) {
            if (verb.equals(PossibleVerbs[i])) {
                return true;
            }
        }
        return false;
    }

    public static boolean checkObject(String object) {
        object = object.toLowerCase();
        for (int i = 0; i < Room.size(); i++) {
            if (object.equals(Room.get(i).nameOfItem)) {
                return true;
            }
        }
        return false;
    }

    public static boolean checkInventory(String object) {
        object = object.toLowerCase();
        for (int i = 0; i < inventory.size(); i++) {
            if (object.equals(inventory.get(i).nameOfItem)) {
                return true;
            }
        }
        return false;
    }

    public static void Use(String object, String object2) {
        object = object.toLowerCase();
        items theItem = inventory.get(0);
        items theItem2 = Room.get(0);
        for (int i = 0; i < inventory.size(); i++) {
            if (object.equals(inventory.get(i).nameOfItem)) {
                theItem = inventory.get(i);
            }
        }
        for (int i = 0; i < Room.size(); i++) {
            if (object2.equals(Room.get(i).nameOfItem)) {
                theItem2 = Room.get(i);
            }
        }

        for (int i = 0; i < inventory.size(); i++) {
            if (object2.equals(inventory.get(i).nameOfItem)) {
                theItem2 = inventory.get(i);
            }
        }


        if (theItem.equals(small_key) && theItem2.equals(tool_box)) {
            if (!theItem2.isUnlocked) {
                System.out.print("The " + theItem2.nameOfItem + " is unlocked!");
                theItem2.isUnlocked = true;
            } else {
                System.out.print("You locked the " + theItem2.nameOfItem);
                theItem2.isUnlocked = false;
                theItem2.isOpen = false;
            }
        } else if (theItem.equals(hammer) && theItem2.equals(statue)) {
            if (!theItem2.isUnlocked) {
                System.out.print("The " + theItem2.nameOfItem + " is shattered to pieces. You have obtained a car_key");
                theItem2.isUnlocked = true;
                inventory.add(car_key);
                ObjectsInGarden.remove(statue);
            }
        }

        //You can win here
        else if (theItem.equals(golden_key) && theItem2.equals(front_door)) {
            System.out.print("You escaped the house... you win!");
        } else if (theItem.equals(car_key) && theItem2.equals(car)) {
            //You win the game HERE
            System.out.print("You RAM the car through the garage door. You win!");
            game = false;
        }
        //KILLER BATTLE
        else if (theItem.equals(knife) && theItem2.equals(killer)) {
            System.out.println("You pull out your knife and stab him. You win!");
            game = false;
        }
    }

    public static void Open(String object) {
        Scanner input = new Scanner(System.in);
        object = object.toLowerCase();
        items theItem = Room.get(0);
        for (int i = 0; i < Room.size(); i++) {
            if (object.equals(Room.get(i).nameOfItem)) {
                theItem = Room.get(i);
            }
        }
        if (theItem.canBeOpened && theItem.isUnlocked && !theItem.isOpen) {
            System.out.print("The " + theItem.nameOfItem + " is opened.");
            theItem.isOpen = true;
            if (theItem.nameOfItem.equals("nightstand")) {
                System.out.println("There is a small key in the nightstand. You shove it in your pocket.");
                inventory.add(small_key);
            }
        }

        else if (theItem.equals(bathroom_cabinet)) {
            System.out.println("You find bandages in the bathroom cabinet! You stuff it in your pocket.");
            inventory.add(bandages);
        }

        else if (theItem.equals(knife_rack)) {
            System.out.println("You pull out a knife from the knife rack! You hold onto it for later.");
            inventory.add(knife);
        }

        else if (theItem.nameOfItem.equals("tool_box")) {
            System.out.println("There's a hammer in the toolbox. You put it on your tool belt.");
            inventory.add(hammer);
        }


    }

    public static void Examine(String object) {
        object = object.toLowerCase();
        items theItem = Room.get(0);
        for (int i = 0; i < Room.size(); i++) {
            if (object.equals(Room.get(i).nameOfItem)) {
                theItem = Room.get(i);
            }
        }
        for (int i = 0; i < inventory.size(); i++) {
            if (object.equals(inventory.get(i).nameOfItem)) {
                theItem = inventory.get(i);
            }
        }

        if (theItem.equals(nightstand)) {
            System.out.print(theItem.descriptionOfItem);
        }
        else if (theItem.equals(pillow)) {
            System.out.print(theItem.descriptionOfItem);
        }
        else if (theItem.equals(small_key)) {
            System.out.print(theItem.descriptionOfItem);
        }
        else if (theItem.equals(bathroom_cabinet)) {
            System.out.print(theItem.descriptionOfItem);
        }
        else if (theItem.equals(bandages)) {
            System.out.print(theItem.descriptionOfItem);
        }
        else if (theItem.equals(car_key)) {
            System.out.print(theItem.descriptionOfItem);
        }
        else if (theItem.equals(bushes)) {
            System.out.print(theItem.descriptionOfItem);
        }
        else if (theItem.equals(statue)) {
            System.out.print(theItem.descriptionOfItem);
        }
        else if (theItem.equals(television)) {
            System.out.print(theItem.descriptionOfItem);
        }
        else if (theItem.equals(sofa)) {
            System.out.print(theItem.descriptionOfItem);
        }
        else if (theItem.equals(tool_box)) {
            System.out.print(theItem.descriptionOfItem);
        }
        else if (theItem.equals(hammer)) {
            System.out.print(theItem.descriptionOfItem);
        }
        else if (theItem.equals(car)) {
            System.out.print(theItem.descriptionOfItem);
        }
        else if (theItem.equals(food)) {
            System.out.print(theItem.descriptionOfItem);
        }
        else if (theItem.equals(knife_rack)) {
            System.out.print(theItem.descriptionOfItem);
        }
        else if (theItem.equals(knife)) {
            System.out.print(theItem.descriptionOfItem);
        }
        else if (theItem.equals(killer)) {
            System.out.print(theItem.descriptionOfItem);
        }
        else if (theItem.equals(golden_key)) {
            System.out.print(theItem.descriptionOfItem);
        }
    }

    public static void Inventory() {
        if (inventory.size() == 0) {
            System.out.println("You are not carrying anything");
        } else {
            for (int i = 0; i < inventory.size(); i++) {
                System.out.print(inventory.get(i).nameOfItem + "\n");
            }
        }
    }

    public static void RoomSelect() {
        if (currentRoom.nameOfRoom.equals("bedroom")) {
            Room = ObjectsInBedroom;
        } else if (currentRoom.nameOfRoom.equals("bathroom")) {
            Room = ObjectsInBathroom;
        } else if (currentRoom.nameOfRoom.equals("kitchen")) {
            Room = ObjectsInKitchen;
        } else if (currentRoom.nameOfRoom.equals("lit hallway")) {
            Room = ObjectsInLitHallway;
        } else if (currentRoom.nameOfRoom.equals("dark hallway")) {
            Room = ObjectsInDarkHallway;
        } else if (currentRoom.nameOfRoom.equals("living room")) {
            Room = ObjectsInLivingroom;
        } else if (currentRoom.nameOfRoom.equals("dining room")) {
            Room = ObjectsInDiningroom;
        } else if (currentRoom.nameOfRoom.equals("foyer")) {
            Room = ObjectsInFoyer;
        } else if (currentRoom.nameOfRoom.equals("garage")) {
            Room = ObjectsInGarage;
        } else if (currentRoom.nameOfRoom.equals("garden")) {
            Room = ObjectsInGarden;
        } else if (currentRoom.nameOfRoom.equals("large hallway")) {
            Room = ObjectsInLargeHallway;
        }
    }

    public static void Walk(String object) {
        object = object.toLowerCase();
        if (currentRoom.nameOfRoom.equals("bedroom")) {
            if (object.equals("south")) {
                if (bedroom_door.isOpen) {
                    System.out.println("It is a narrow corridor and there is not much to it. There is a door to the bathroom on the east. There is a door to the bedroom to the west. The path to the north seems dark.");
                    currentRoom.nameOfRoom = "lit hallway";
                } else if (object.equals("north") || object.equals("east") || object.equals("west")) {
                    System.out.println("Since there is no door in this direction, you cannot move");
                } else {
                    System.out.println("There is no such a direction");}
            }
        } else if (currentRoom.nameOfRoom.equals("bathroom")) {
            if (object.equals("south")) {
                currentRoom.nameOfRoom = "lit hallway";
                System.out.println("It is a narrow corridor and there is not much to it. There is a door to the bathroom on the east. There is a door to the bedroom to the west. The path to the north seems dark.");
            } else if (object.equals("north") || object.equals("east") || object.equals("west")) {
                System.out.println("Since there is no door in this direction, you cannot move");
            } else {
                System.out.println("There is no such a direction");}

        } else if (currentRoom.nameOfRoom.equals("lit hallway")) {
            if (object.equals("east")) {
                if (bathroom_door.isOpen) {
                    Room = ObjectsInBathroom;
                    System.out.println("It is a bathroom. \nThere is a cabinet with a red cross on it. There is a door to the south.");
                    currentRoom.nameOfRoom = "bathroom";
                } else {
                    System.out.println("Since the bathroom door is closed, you cannot move");}
            } else if (object.equals("west")) {

                if (hallway_door.isOpen) {
                    Room = ObjectsInLargeHallway;
                    System.out.println("Game Over, you ran into the killer. You've been murdered");
                    currentRoom.nameOfRoom = "large hallway";
                    game = false;
                } else {
                    System.out.println("Since the hallway_door is closed, you cannot move");}
            } else if (object.equals("north")) {
                Room = ObjectsInDarkHallway;
                currentRoom.nameOfRoom = "dark hallway";
                System.out.println("It is a narrow corridor that is pretty dark. There is a garden door to the east and a living room door to the west.");
            } else if (object.equals("south")) {
                System.out.println("Since there is no door in this direction, you cannot move");
            } else {
                System.out.println("There is no such a direction");
            }
        } else if (currentRoom.nameOfRoom.equals("dark hallway")) {
            if (object.equals("south")) {
                Room = ObjectsInLitHallway;
                currentRoom.nameOfRoom = "lit hallway";
                System.out.println("It is a narrow corridor and there is not much to it. There is a door to the bathroom on the north.");
            }else if (object.equals("west")) {
                Room = ObjectsInLivingroom;
                currentRoom.nameOfRoom = "living room";
                System.out.println("It's a pretty standard living room. There is a television playing there. There is a door to the north which leads to the garage. There is a door to the west that leads to a hallway.");
            } else if (object.equals("east")) {
                Room = ObjectsInGarden;
                currentRoom.nameOfRoom = "garden";
                System.out.println("There's some fresh air in this garden. You can see a statue with something inside of it. Maybe we have to break it.");
            } else if (object.equals("north")) {
                System.out.println("Since there is no door in this direction, you cannot move");
            } else {
                System.out.println("There is no such a direction");}
        } else if (currentRoom.nameOfRoom.equals("garden")) {
            if (object.equals("south")) {
                Room = ObjectsInDarkHallway;
                currentRoom.nameOfRoom = "dark hallway";
                System.out.println("It is a narrow corridor that is pretty dark. There is a garden door to the east and a living room to the west.");
            } else if (object.equals("west") || object.equals("east") || object.equals("north") ) {
                System.out.println("Since there is no door in this direction, you cannot move");
            } else {
                System.out.println("There is no such a direction");}
        } else if (currentRoom.nameOfRoom.equals("living room")) {
            if (object.equals("north")) {
                Room = ObjectsInGarage;
                currentRoom.nameOfRoom = "garage";
                System.out.println("A typical garage. Relatively spacious. There is a car there that seems to need a key to drive. Maybe you can bust out of the place with the car. The door to the living room is to the south.");
            }else if (object.equals("south")) {
                Room = ObjectsInDarkHallway;
                currentRoom.nameOfRoom = "dark hallway";
                System.out.println("It is a narrow corridor that is pretty dark. There is a garden door to the east and a living room to the west.");
            } else if (object.equals("west")) {
                Room = ObjectsInLargeHallway;
                currentRoom.nameOfRoom = "large hallway";
                System.out.println("It's a large hallway. There seems to be some large object standing in the middle of it. \nYou should be careful.");
            } else if (object.equals("east")) {
                System.out.println("Since there is no door in this direction, you cannot move");
            } else {
                System.out.println("There is no such a direction");}
        } else if (currentRoom.nameOfRoom.equals("garage")) {
            if (object.equals("south")) {
                Room = ObjectsInLivingroom;
                currentRoom.nameOfRoom = "living room";
                System.out.println("It's a pretty standard living room. There is a television playing there. There is a door to the north which leads to the garage. There is a door to the west that leads to a dangerous hallway.");
            } else if (object.equals("west") || object.equals("east") || object.equals("north") ) {
                System.out.println("Since there is no door in this direction, you cannot move");
            } else {
                System.out.println("There is no such a direction");}

        } else if (currentRoom.nameOfRoom.equals("large hallway")) {
            if (object.equals("north")) {
                Room = ObjectsInDiningroom;
                currentRoom.nameOfRoom = "dining room";
                System.out.println ("It's a dining room with food on the table still.\nThere is a door to the kitchen to the south. ");
            }else if (object.equals("east")) {
                Room = ObjectsInFoyer;
                currentRoom.nameOfRoom = "foyer";
                System.out.println("It's a pretty big foyer. The door leading to the outside is there. It appears to be locked.");
            } else if (object.equals("south")) {
                Room = ObjectsInLivingroom;
                currentRoom.nameOfRoom = "living room";
                System.out.println("It's a pretty standard living room. There is a television playing there.");
            } else if (object.equals("west")) {
                System.out.println("Game Over, you ran into the killer. You've been murdered");
                currentRoom.nameOfRoom = "large hallway";
                game = false;
            } else {
                System.out.println("There is no such a direction");}

        } else if (currentRoom.nameOfRoom.equals("dining room")) {
            if (object.equals("east")) {
                Room = ObjectsInKitchen;
                currentRoom.nameOfRoom = "kitchen";
                System.out.println ("A beautiful looking kitchen. \nThere's a knife rack on the counter. There's a door leading to the foyer to the west.");
            }else if (object.equals("south")) {
                Room = ObjectsInLargeHallway;
                currentRoom.nameOfRoom = "large hallway";
                System.out.println("It's a large hallway. There seems to be some large object standing in the middle of it. \nYou should be careful.");
            } else if (object.equals("west") || object.equals("north") ) {
                System.out.println("Since there is no door in this direction, you cannot move");
            } else {
                System.out.println("There is no such a direction");}

        } else if (currentRoom.nameOfRoom.equals("kitchen")) {
            if (object.equals("south")) {
                Room = ObjectsInDiningroom;
                currentRoom.nameOfRoom = "dining room";
                System.out.println ("It's a dining room with food on the table still.\nThere is a door to the kitchen to the east.");
            }else if (object.equals("east")) {
                Room = ObjectsInFoyer;
                currentRoom.nameOfRoom = "foyer";
                System.out.println("It's a pretty big foyer. The door leading to the north which leads to the outside. It appears to be locked. There is a door leading to the kitchen on the west.");
            } else if (object.equals("west") || object.equals("north") ) {
                System.out.println("Since there is no door in this direction, you cannot move");
            } else {
                System.out.println("There is no such a direction");}

        } else if (currentRoom.nameOfRoom.equals("foyer")) {
            if (object.equals("north")) {
                Room = ObjectsInFoyer;
                currentRoom.nameOfRoom = "foyer";
                System.out.println("It's a pretty big foyer. The door leading to the north which leads to the outside. It appears to be locked. There is a door leading to the kitchen on the west.");
            }else if (object.equals("south")) {
                Room = ObjectsInLargeHallway;
                currentRoom.nameOfRoom = "large hallway";
                System.out.println( "It's a large hallway. There seems to be some large object standing in the middle of it. \nYou should be careful.");
            }else if (object.equals("west")) {
                Room = ObjectsInKitchen;
                currentRoom.nameOfRoom = "kitchen";
                System.out.println("A beautiful looking kitchen. \nThere's a knife rack on the counter. There's a door leading to the foyer to the east.");
            } else if (object.equals("east")) {
                System.out.println("Since there is no door in this direction, you cannot move");
            } else {
                System.out.println("There is no such a direction");}

        }

    }
}

